module.exports = {
  apps: [
    { 
      name: 'panel',
      script: './panel.js',
      watch: ['panel.js'],
      // Delay between restart
      watch_delay: 2000,
      ignore_watch: ['node_modules', 'public'],
      watch_options: {
        followSymlinks: false,
      },
    },
  ],
};
