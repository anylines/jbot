#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Author   : Chiupam
# @Data     : 2021-06-15
# @Version  : v 2.5
# @Updata   :
# @Future   :


from .. import chat_id, jdbot, _ConfigDir, logger, api_id, api_hash, proxystart, proxy, _ScriptsDir, _OwnDir, _JdbotDir, TOKEN, _LogDir
from ..bot.utils import cmd, press_event, backfile, jdcmd, _DiyDir, V4, QL, _ConfigFile, myck
from telethon import events, TelegramClient
import re, json, requests, asyncio, os, sys, time, datetime


if proxystart:
    client = TelegramClient("user", api_id, api_hash, proxy=proxy, connection_retries=None).start()
else:
    client = TelegramClient("user", api_id, api_hash, connection_retries=None).start()


with open(f"{_ConfigDir}/diybotset.json", 'r', encoding='utf-8') as f:
    diybotset = json.load(f)
my_chat_id = int(diybotset['my_chat_id'])


bot_id = int(TOKEN.split(':')[0])


def checkCookie1():
    expired = []
    cookies = myck(_ConfigFile)
    for cookie in cookies:
        cknum = cookies.index(cookie) + 1
        if checkCookie2(cookie):
            expired.append(cknum)
    return expired, cookies


def checkCookie2(cookie):
    url = "https://me-api.jd.com/user_new/info/GetJDUserInfoUnion"
    headers = {
        "Host": "me-api.jd.com",
        "Accept": "*/*",
        "Connection": "keep-alive",
        "Cookie": cookie,
        "User-Agent": "jdapp;iPhone;9.4.4;14.3;network/4g;Mozilla/5.0 (iPhone; CPU iPhone OS 14_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148;supportJDSHWK/1",
        "Accept-Language": "zh-cn",
        "Referer": "https://home.m.jd.com/myJd/newhome.action?sceneval=2&ufc=&",
        "Accept-Encoding": "gzip, deflate, br"
    }
    try:
        r = requests.get(url, headers=headers).json()
        if r['retcode'] == '1001':
            return True
        else:
            return False
    except:
        return False


def getbean(i, cookie, url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36",
        "Accept-Encoding": "gzip,compress,br,deflate",
        "Cookie": cookie,
    }
    result, o = '', '\n\t\t└'
    try:
        r = requests.get(url=url, headers=headers)
        res = r.json()
        if res['code'] == '0':
            followDesc = res['result']['followDesc']
            if followDesc.find('成功') != -1:
                try:
                    for n in range(len(res['result']['alreadyReceivedGifts'])):
                        redWord = res['result']['alreadyReceivedGifts'][n]['redWord']
                        rearWord = res['result']['alreadyReceivedGifts'][n]['rearWord']
                        result += f"{o}领取成功，获得{redWord}{rearWord}"
                except:
                    giftsToast = res['result']['giftsToast'].split(' \n ')[1]
                    result = f"{o}{giftsToast}"
            elif followDesc.find('已经') != -1:
                result = f"{o}{followDesc}"
        else:
            result = f"{o}Cookie 可能已经过期"
    except Exception as e:
        if str(e).find('(char 0)') != -1:
            result = f"{o}访问发生错误：无法解析数据包"
        else:
            result = f"{o}访问发生错误：{e}"
    return f"\n京东账号{i}{result}\n"


# user?
@client.on(events.NewMessage(chats=[bot_id, my_chat_id], from_users=chat_id, pattern=r"/user"))
async def fortest(event):
    try:
        msg = await jdbot.send_message(chat_id, '《《《  user.py运行正常  》》》')
        #await asyncio.sleep(5)
        #await jdbot.delete_messages(chat_id, msg)
    except Exception as e:
        await jdbot.send_message(chat_id, 'something wrong,I\'m sorry\n' + str(e))
        logger.error('something wrong,I\'m sorry\n' + str(e))



@client.on(events.NewMessage(chats=[-1001419355450, -1001284907085, -1001320212725,-1001213090633, my_chat_id]))
async def followshop(event):
    """
    关注店铺
    """
    try:
        cookies = myck(_ConfigFile)
        url = re.findall(re.compile(r"[(](https://api\.m\.jd\.com.*?)[)]", re.S), event.message.text)
        if url != [] and len(cookies) > 0:
            i = 0
            info = '关注店铺\n\n'
            for cookie in cookies:
                try:
                    i += 1
                    info += getbean(i, cookie, url[0])
                except:
                    continue
            result = re.findall(r'.*获得(\d+)京豆', info)
            UserSum = len(result)
            if '京豆' in info and len(result) >= 1:
                await jdbot.send_message(chat_id, f'关注店铺：本次有{UserSum}个号领到{result[0]}京豆')
            else:
                await jdbot.send_message(chat_id, '关注店铺：你好，翻车了，没豆')
        else:
            return
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}") 


@client.on(events.NewMessage(chats=bot_id, from_users=bot_id, pattern=r'(\n|.)*(店铺签到检测|抽奖有礼|加购有礼|组队瓜分京豆1), 开始!'))
async def del_botmsg(event):
    """
    bot发送来的日志，进行删除
    """
    try:
        if event.message.text and event.chat_id == bot_id:
            await client.delete_messages(event.chat_id, event.message)
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")


@client.on(events.NewMessage(chats=[-1001169232926, -1001284907085, -1001320212725,-1001213090633, my_chat_id], pattern=r"(\n|.)*export (jd_zdjr_activity.*|jd_joinTeam_activityId.*|ISV_SHOP_ID.*|FAV_SHOP_ID.*|OPEN_CARD_.*|FOLLOW_SHOP_ID.*|jd_smiek_addCart_activityUrl|jd_smiek_luckDraw_activityUrl)=[\"|\'].*[\"|\']"))
async def jian_kong(event):
    """
    监控整合
    """
    try:
        if event.chat_id == -1001320212725 and "Annyoo" in event.post_author:
            return
        messages = event.message.text.split("export ")
        messages = filter(None, messages)
        end = False
        identity=''
        kv_names = ['jd_zdjr_activityId',
                    'jd_zdjr_activityUrl',
                    'OPEN_CARD_SHOP_ID',
                    'OPEN_CARD_VENDER_ID',
                    'FAV_SHOP_ID',
                    'FAV_VENDER_ID',
                    'ISV_SHOP_ID',
                    'ISV_VENDER_ID',
                    'ISV_RED_URL',
                    'ISV_SIGN',
                    'jd_joinTeam_activityId',
                    'jd_joinTeam_activityUrl',
                    'jd_joinTeam_signUuid',
                    'FOLLOW_SHOP_ID',
                    'FOLLOW_VENDER_ID',
                    'FOLLOW_ACT_ID',
                    'FOLLOW_SIGN',
                    'jd_smiek_addCart_activityUrl',
                    'jd_smiek_luckDraw_activityUrl'
        ]
        for message in messages:
            if "=" not in message:
                continue
            if "jd_joinTeam_" in message:
                identity = "开卡组队"
            elif "OPEN_CARD_" in message:
                identity = "入会"
            elif "FAV_" in message:
                identity = "收藏有礼"
            elif "ISV_" in message:
                identity = "关注有礼"
            elif "jd_zdjr" in message:
                identity = "组队"
            elif "FOLLOW_SHOP_ID" in message:
                identity = "特效关注有礼"
            elif "jd_smiek_addCart_activityUrl" in message:
                identity = "加购有礼"
            elif "jd_smiek_luckDraw_activityUrl" in message:
                identity = "抽奖"
            template = re.compile(r"((?:\n|.)*=[\"|\'].*[\"|\'])(\n|.*).*")
            kv = re.sub(r"\n.*", "", re.sub(template, r"\1", message)).replace("*", "").replace("\'", "\"").replace("`", "")
            kname = kv.split("=")[0]
            vname = re.findall(r"(\".*\"|'.*')", kv)[0][1:-1]
            if re.search(r'(jd_zdjr_activityId|jd_zdjr_activityUrl)', kname) and len(vname) != 32:
                await jdbot.send_message(chat_id, f"无牌组队车竟想漂移入弯……已成功拦截！")
                return
            with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f1:
                configs = f1.read()
            if kv in configs:
                continue
            if configs.find(kname) != -1 and any(kname == s for s in kv_names):
                configs = re.sub(f'{kname}=(\"|\').*(\"|\')', kv, configs)
                end = f"替换（{identity}）变量成功"
            elif configs.find(kname) == -1 and any(kname == s for s in kv_names):
                if V4:
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                        configs = f2.readlines()
                    for config in configs:
                        if config.find("第五区域") != -1 and config.find("↑") != -1:
                            end_line = configs.index(config)
                            break
                    configs.insert(end_line - 1, f'export {kname}="{vname}"\n')
                    configs = ''.join(configs)
                else:
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                        configs = f2.read()
                    configs += f'export {kname}="{vname}"\n'
                end = f"新增（{identity}）变量成功"
            with open(f"{_ConfigDir}/config.sh", 'w', encoding='utf-8') as f3:
                f3.write(configs)
        if end:
            msg = await jdbot.send_message(chat_id, end)
            if "组队" == identity:
                await cmd("jtask /jd/own/0116/00smiek_jd_zdjr.js now")
            elif "入会" == identity:
                await cmd('jtask /jd/own/0116/0jd_open_card_by_shopid.js now')
            elif "收藏有礼" == identity:
                await cmd('jtask /jd/own/0116/0jd_fav_shop_gift.js now')
            elif "关注有礼" == identity:
                await cmd('jtask /jd/own/0116/0jd_follow_wxshop_gift.js now')
            elif "开卡组队" == identity:
                await cmd('jtask /jd/own/0116/0gua_joinTeam.js now')
            elif "特效关注有礼" == identity:
                await cmd('jtask /jd/own/0116/0ShopGift.js now')
            elif "加购有礼" == identity:
                await cmd('jtask /jd/own/0116/0gua_addCart.js now')
            elif "抽奖" == identity:
                await cmd('jtask /jd/own/0116/0gua_luckDraw.js now')
            else:
                await jdbot.edit_message(msg, f"车况不佳，导致发生严重意外!")
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")


@client.on(events.NewMessage(chats=[-1001169232926, -1001284907085, -1001320212725,-1001213090633, bot_id, my_chat_id], pattern=r'(\n|.)*(export\s)?MyShopToken\d*=(".*"|\'.*\')|^店铺签到检测.*'))
async def shoptoken(event):
    """
    店铺签到
    """
    try:
        message0 = event.message.text
        if "export" in message0:
            messages = event.message.text.split("export ")
            messages = filter(None, messages)
            for message in messages:
                if "=" not in message:
                    continue
                msg = await jdbot.send_message(chat_id, '监控到店铺签到变量 . . .')
                template = re.compile(r"((?:\n|.)*=[\"|\'].*[\"|\'])(\n|.*).*")
                kv = re.sub(r"\n.*", "", re.sub(template, r"\1", message)).replace("*", "").replace("\'", "\"")
                value = re.findall(r"(\".*\"|'.*')", kv)[0][1:-1]
                with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f1:
                    configs = f1.read()
                result = re.findall(r'export MyShopToken\d+=[\'|\"](.+)[\'|\"]', configs)
                if len(value) != 32:
                    await jdbot.edit_message(msg, f"店铺签到：\n\n监控到Token变量，该变量不正确！\n\n当前店铺数量：{len(result)}")
                    continue
                elif configs.find(value) != -1:
                    await jdbot.edit_message(msg, f"店铺签到：\n\n监控到Token变量，该变量已存在！\n\n当前店铺数量：{len(result)}")
                    continue
                elif len(result) >= 20:
                    await jdbot.edit_message(msg, f"店铺签到：\n\n已满20个Token变量，不进行新增 . . .\n\n当前店铺数量：{len(result)}")
                    continue
                elif "export MyShopToken" not in configs:
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                        configlist = f2.readlines()
                    for config in configlist:
                        if "################" in config and "店铺签到" in config:
                            line = configlist.index(config)
                            break
                    configlist.insert(line + 1, f'export MyShopToken1="{value}"\n')
                    info = f'店铺签到，成功新增以下Token变量：\n\n```export MyShopToken1="{value}"```\n\n当前店铺数量：{len(result)+1}'
                    await jdbot.edit_message(msg, info)
                elif len(result) == 0 and "export MyShopToken1" in configs:
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                        configlist = f2.readlines()
                    for config in configlist:
                        if "export MyShopToken1" in config:
                            line = configlist.index(config)
                            break
                    configlist[line] = f'export MyShopToken1="{value}"\n'
                    info = f'店铺签到，成功新增以下Token变量：\n\n```export MyShopToken1="{value}"```\n\n当前店铺数量：{len(result)+1}'
                    await jdbot.edit_message(msg, info)
                elif len(result) != 0:
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                        configlist = f2.readlines()
                    for config in configlist:
                        if "export MyShopToken" in config:
                            number = int(re.findall(r'\d+', config.split("=")[0])[0]) + 1
                            line = configlist.index(config) + 1
                    configlist.insert(line, f'export MyShopToken{number}="{value}"\n')
                    info = f'店铺签到，成功新增以下Token变量：\n\n```export MyShopToken{number}="{value}"```\n\n当前店铺数量：{len(result)+1}'
                    await jdbot.edit_message(msg, info)
                with open(f"{_ConfigDir}/config.sh", 'w', encoding='utf-8') as f3:
                    f3.write("".join(configlist))
        elif "店铺签到检测" in message0:
            kv = message0.replace("\n", "").split("。")
            chart = []
            check = []
            m = -1
            for _ in kv:
                m += 1
                check += re.findall(r"【店铺.*已签到.*", kv[m])
                chart += re.findall(f"【店铺(\d+)】签到活动已失效", kv[m])
            n = -1
            for _ in check:
                day = []
                n += 1
                day += re.findall(f"签到(\d+)天,获得\d+豆；\s\s└已签到：(\d+)天", check[n])[0]
                if int(day[1]) >= int(day[0]):
                    chart += re.findall(f"【店铺(\d+)】", check[n])
            j = -1
            for _ in check:
                j += 1
                sumbeans = sum(list(map(int, re.findall(f"└签到\d+天,获得(\d+)豆", check[j]))))
                if sumbeans <= 10:
                    chart += re.findall(f"【店铺(\d+)】", check[j])
            chart = list(set(chart)) # 列表去重，因为判断天数 和 豆子数量的 会有重复
            charts = sorted(chart,key=int)
            p = -1
            for _ in charts:
                p += 1
                nums = charts[p]
                num = int(nums) - p
                with open(f'{_ConfigDir}/config.sh', 'r', encoding='utf-8') as f3:
                    configs = f3.read()
                config = re.findall(r'export MyShopToken\d+=[\'|\"](.+)[\'|\"]', configs)
                if len(config) == 1:
                    configs = re.sub(r'export MyShopToken1=[\'|\"].*[\'|\"]', r'export MyShopToken1=""', configs)
                    with open(f'{_ConfigDir}/config.sh', 'w', encoding='utf-8') as f4:
                        f4.write(configs)
                    info = f"监测到店铺{nums}签到已结束 . . .\n\n成功移除店铺{nums}，当前店铺数量：0\n"
                    await jdbot.send_message(chat_id, info)
                    break
                i = 0
                oldtext = ""
                for index in range(len(config)):
                    i += 1
                    oldtext += f'export MyShopToken{i}="{config[int(i) - 1]}"\n'
                del config[int(num) - 1]
                i = 0
                newtext = ""
                for index in range(len(config)):
                    i += 1
                    newtext += f'export MyShopToken{i}="{config[int(i) - 1]}"\n'
                configs = re.sub(oldtext, newtext, configs)
                with open(f'{_ConfigDir}/config.sh', 'w', encoding='utf-8') as f5:
                    f5.write(configs)
                info = f"监测到店铺{nums}签到已结束 . . .\n\n成功移除店铺{nums}，当前店铺数量：{len(config)}\n"
                await jdbot.send_message(chat_id, info)
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")



#@client.on(events.NewMessage(chats=[-1001419355450, my_chat_id], pattern=r"^#开卡"))
#async def myzoo(event):
#    """
#    动物园开卡
#    关注频道：https://t.me/zoo_channel
#    """
#    try:
#        messages = event.message.text
#        url = re.findall(re.compile(r"[(](https://raw\.githubusercontent\.com.*?)[)]", re.S), messages)
#        if url == []:
#            return
#        else:
#            url = url[0]
#        speeds = ["http://ghproxy.com/", "https://mirror.ghproxy.com/", ""]
#        for speed in speeds:
#            resp = requests.get(f"{speed}{url}").text
#            if resp:
#                break
#        if resp:
#            fname = url.split('/')[-1]
#            fpath = f"{_ScriptsDir}/{fname}"
#            backfile(fpath)
#            with open(fpath, 'w+', encoding='utf-8') as f:
#                f.write(resp)
#            with open(f"{_ConfigDir}/diybotset.json", 'r', encoding='utf-8') as f:
#                diybotset = json.load(f)
#            run = diybotset['zoo开卡自动执行']
#            if run == "False":
#                await jdbot.send_message(chat_id, f"开卡脚本将保存到{_ScriptsDir}目录\n自动运行请在config目录diybotset.json中设置为Ture")
#            else:
#                cmdtext = f'{jdcmd} {fpath} now'
#                await jdbot.send_message(chat_id, f"开卡脚本将保存到{_ScriptsDir}目录\n不自动运行请在config目录diybotset.json中设置为False")
#                await cmd(cmdtext)
#    except Exception as e:
#        await jdbot.send_message(chat_id, 'something wrong,I\'m sorry\n' + str(e))
#        logger.error('something wrong,I\'m sorry\n' + str(e))


@client.on(events.MessageEdited(chats=[-1001235868507,-1001213090633, my_chat_id], from_users=1049578757))
@client.on(events.NewMessage(chats=[-1001235868507,-1001213090633, my_chat_id], from_users=1049578757))
async def guaopencard(event):
    """
    羊群瓜佬开卡
    """
    try:
        if event.message.document: # 只监控文档格式
            filename = event.message.file.name
            try:
                if len(re.findall(r'gua_opencard\d+\.js', filename)) != 0:
                    msg = await jdbot.send_message(chat_id, '好家伙，瓜佬又发开卡脚本了！')
                    cardnum = re.findall(r'gua_opencard(\d+).js', filename)[0]
                    backfile(f'{_ScriptsDir}/{filename}') # 如有同名旧文件备份为.bak
                    await client.forward_messages(f'@AnyLine_jd_v4_vps_bot', event.message) # 转发给自己小号bot
                    await client.download_media(event.message, _ScriptsDir)
                    cmdtext = f'{jdcmd} {_ScriptsDir}/{filename} now'
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f0:
                        result = f0.read()
                    expcard = re.findall(f'export guaopencard_All="true"', result)
                    expaddSku = re.findall(f'export guaopencard_addSku_All="true"', result)
                    expdraw = re.findall(f'export guaopencard_draw_All="true"', result)
                    expdRun = re.findall(f'export guaopencardRun_All="true"', result)
                    guaexps = ['guaopencard_All', 'guaopencard_addSku_All', 'guaopencard_draw_All', 'guaopencardRun_All']
                    for i in guaexps:
                        with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f1:
                            result0 = f1.read()
                        if len(re.findall(f'export {i}="true"', result0)) == 0:
                            with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                                configs = f2.readlines()
                            for config in configs:
                                if config.find("第五区域") != -1 and config.find("↑") != -1:
                                    end_line = configs.index(config)
                                    break
                            configs.insert(end_line - 1, f'export {i}="true"\n')
                            configs = ''.join(configs)
                            with open(f"{_ConfigDir}/config.sh", 'w', encoding='utf-8') as f3:
                                f3.write(configs)
                    if len(expcard) != 0 and len(expaddSku) != 0 and len(expdraw) != 0 and len(expdRun) != 0:
                        await jdbot.edit_message(msg, f'好家伙，瓜佬又发开卡脚本了！\n\n开卡变量已存在，无需写入\n开始执行脚本：gua_opencard{cardnum}.js')
                    else:
                        await jdbot.edit_message(msg, f'好家伙，瓜佬又发开卡脚本了！\n\n成功写入开卡变量\n开始执行脚本：gua_opencard{cardnum}.js')
                    #执行脚本
                    await cmd(cmdtext)
                elif len(re.findall(r'gua_invite_join_shop\d+\.js', filename)) != 0:
                    msg = await jdbot.send_message(chat_id, '好家伙，瓜佬又发邀新入会送京豆脚本了！')
                    cardnum = re.findall(r'gua_invite_join_shop(\d+).js', filename)[0]
                    backfile(f'{_ScriptsDir}/{filename}')
                    await client.forward_messages(f'@AnyLine_jd_v4_vps_bot', event.message)
                    await client.download_media(event.message, _ScriptsDir)
                    cmdtext = f'{jdcmd} {_ScriptsDir}/{filename} now'
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f0:
                        result = f0.read()
                    exp_joinshop = re.findall(f'export gua_invite_join_shop_id{cardnum}="1,2,3,4,5"', result)
                    oldexp_joinshop = re.findall(f'export gua_invite_join_shop_id{int(cardnum)-1}="1,2,3,4,5"', result)
                    if len(oldexp_joinshop) != 0:
                        deloldexp = re.sub(f'(?:^|\n?)export gua_invite_join_shop_id{int(cardnum)-1}="1,2,3,4,5"\n?','\n',result) # 删除旧变量
                        with open(f"{_ConfigDir}/config.sh", 'w',encoding='utf-8') as f1:
                            f1.write(deloldexp)
                    if len(exp_joinshop) != 0:
                        if len(oldexp_joinshop) != 0:
                            await jdbot.edit_message(msg, f'好家伙，瓜佬又发邀新入会送京豆脚本了！\n\n成功删除旧变量\n新变量已存在，无需写入\n开始执行脚本：gua_invite_join_shop{cardnum}.js')
                        else:
                            await jdbot.edit_message(msg, f'好家伙，瓜佬又发邀新入会送京豆脚本了！\n\n旧变量不存在，无需删除\n新变量已存在，无需写入\n开始执行脚本：gua_invite_join_shop{cardnum}.js')
                    else:
                        #写入变量
                        with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                            configs = f2.readlines()
                        for config in configs:
                            if config.find("第五区域") != -1 and config.find("↑") != -1:
                                end_line = configs.index(config)
                                break
                        configs.insert(end_line - 1, f'export gua_invite_join_shop_id{cardnum}="1,2,3,4,5"\n')
                        configs = ''.join(configs)
                        with open(f"{_ConfigDir}/config.sh", 'w', encoding='utf-8') as f3:
                            f3.write(configs)
                        if len(oldexp_joinshop) != 0:
                            await jdbot.edit_message(msg, f'好家伙，瓜佬又发邀新入会送京豆脚本了！\n\n成功删除旧变量\n成功写入新变量\n开始执行脚本：gua_invite_join_shop{cardnum}.js')
                        else:
                            await jdbot.edit_message(msg, f'好家伙，瓜佬又发邀新入会送京豆脚本了！\n\n旧变量不存在，无需删除\n成功写入新变量\n开始执行脚本：gua_invite_join_shop{cardnum}.js')
                    #执行脚本
                    await cmd(cmdtext)
                elif len(re.findall(r'gua_UnknownTask\d+\.js', filename)) != 0:
                    msg = await jdbot.send_message(chat_id, '好家伙，瓜佬又发未知加购脚本了！')
                    cardnum = re.findall(r'gua_UnknownTask(\d+).js', filename)[0]
                    backfile(f'{_ScriptsDir}/{filename}')
                    await client.forward_messages(f'@AnyLine_jd_v4_vps_bot', event.message)
                    await client.download_media(event.message, _ScriptsDir)
                    cmdtext = f'{jdcmd} {_ScriptsDir}/{filename} now'
                    with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f0:
                        result = f0.read()
                    exp_Task = re.findall(f'export guaunknownTask_addSku_All="true"', result)
                    if len(exp_Task) != 0:
                        await jdbot.edit_message(msg, f'好家伙，瓜佬又发未知加购脚本了！\n\n变量已存在，无需写入\n开始执行脚本：gua_UnknownTask{cardnum}.js')
                    else:
                        with open(f"{_ConfigDir}/config.sh", 'r', encoding='utf-8') as f2:
                            configs = f2.readlines()
                        for config in configs:
                            if config.find("第五区域") != -1 and config.find("↑") != -1:
                                end_line = configs.index(config)
                                break
                        configs.insert(end_line - 1, f'export guaunknownTask_addSku_All="true"\n')
                        configs = ''.join(configs)
                        with open(f"{_ConfigDir}/config.sh", 'w', encoding='utf-8') as f3:
                            f3.write(configs)
                        await jdbot.edit_message(msg, f'好家伙，瓜佬又发未知加购脚本了！\n\n成功写入变量\n开始执行脚本：gua_UnknownTask{cardnum}.js')
                    #执行脚本
                    await cmd(cmdtext)
                elif len(re.findall(r'gua_jointeam(?:\d+)?\.js', filename)) != 0:
                    msg = await jdbot.send_message(chat_id, '好家伙，瓜佬又发jointeam脚本了！')
                    cardnum = ''
                    cardnumlist = re.findall(r'gua_jointeam(\d+)\.js', filename)
                    if len(cardnumlist) != 0:
                        cardnum = cardnumlist[0]
                    backfile(f'{_ScriptsDir}/{filename}')
                    await client.forward_messages(f'@AnyLine_jd_v4_vps_bot', event.message)
                    await client.download_media(event.message, _ScriptsDir)
                    cmdtext = f'{jdcmd} {_ScriptsDir}/{filename} now'
                    await jdbot.edit_message(msg, f'好家伙，瓜佬又发jointeam脚本了！\n\n开始执行脚本：gua_jointeam{cardnum}.js')
                    await cmd(cmdtext)
                elif len(re.findall(r'.*\.js', filename)) != 0:
                    await jdbot.send_message(chat_id, '汇报主人：\n\n瓜佬又发什么别的脚本了！赶快去看看吧！')
                    await client.forward_messages(f'@AnyLine_jd_v4_vps_bot', event.message)
            except:
                return
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")


@client.on(events.NewMessage(chats=[-1001159808620, -1001213090633, my_chat_id], pattern=r".*京豆雨.*"))
async def redrain(event):
    """
    龙王庙京豆雨
    关注频道：https://t.me/longzhuzhu
    """
    try:
        if V4:
            if not os.path.exists('/jd/config/jredrain.sh'):
                cmdtext = 'cd /jd/config && wget https://raw.githubusercontent.com/Annyoo2021/own/ownn/jredrain.sh'
                await cmd(cmdtext)
        else:
            if not os.path.exists('/ql/jredrain.sh'):
                cmdtext = 'cd /ql/config && wget https://raw.githubusercontent.com/Annyoo2021/own/ownn/jredrain.sh'
                await cmd(cmdtext)
        message = event.message.text
        RRAs = re.findall(r'RRA.*', message)
        Times = re.findall(r'开始时间.*', message)
        for RRA in RRAs:
            i = RRAs.index(RRA)
            if V4:
                cmdtext = f'/cmd bash /jd/config/jredrain.sh {RRA}'
            else:
                cmdtext = f'/cmd bash /jd/config/jredrain.sh {RRA}'
            await client.send_message(bot_id, cmdtext)
            await jdbot.send_message(chat_id, f'打雷了、要下雨啦！\n监控到RRA：{RRA}\n开始替换RRA并设置定时！')
    except Exception as e:
        await jdbot.send_message(chat_id, 'something wrong,I\'m sorry\n' + str(e))
        logger.error('something wrong,I\'m sorry\n' + str(e))


# -100123456789 是频道的id，例如我需要把频道1的消息转发给机器人，则下一行的相应位置中填写频道1的id
#@client.on(events.NewMessage(chats=-1001419355450))
#async def myforward(event):
#    try:
#        # -100123456789 是频道的id，例如我需要把频道1的消息转发给机器人，则下一行的相应位置中填写频道1的id
#        await client.forward_messages(bot_id, event.id, -1001419355450)
#    except Exception as e:
#        await jdbot.send_message(chat_id, 'something wrong,I\'m sorry\n' + str(e))
#        logger.error('something wrong,I\'m sorry\n' + str(e))


# @client.on(events.NewMessage(chats=[-1001431256850, my_chat_id], from_users=1185488678))
# async def myupuser(event):
#     """
#     关注频道：https://t.me/jd_diy_bot_channel
#     """
#     try:
#         if event.message.file:
#             fname = event.message.file.name
#             try:
#                 if fname.endswith("bot-06-21.py") or fname.endswith("user.py"):
#                     path = f'{_JdbotDir}/diy/{fname}'
#                     backfile(path)
#                     await client.download_file(input_location=event.message, file=path)
#                     from ..diy.bot import restart
#                     await restart()
#             except:
#                 return
#     except Exception as e:
#         await jdbot.send_message(chat_id, 'something wrong,I\'m sorry\n' + str(e))
#         logger.error('something wrong,I\'m sorry\n' + str(e))
