#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#Author：annyooo

from .. import chat_id, logger, jdbot
from ..bot.utils import press_event, row, split_list
from telethon import events, Button
from asyncio import exceptions
import re, sys, os, asyncio

path = f'/jd/config/config.sh'
pushpath = f"/jd/config/push.sh"


async def read_ckts():
    try:
        with open(path, 'r', encoding='utf-8') as f0:
            configs = f0.read()
        cknums = re.findall(f'(?:^|\n)Cookie(\d+)=[\"|\']pt_key=.+;pt_pin=.+;[\"|\']', configs)
        changes = ''
        adds = ''
        if len(cknums) != 0:
            for i in cknums:
                with open(path, 'r', encoding='utf-8') as f1:
                    configs = f1.readlines()
                    for config in configs:
                        if config.find(f'Cookie{i}="pt_key=') != -1:
                            namenum = configs.index(config)-1
                result = configs[namenum]
                namelist = re.findall(r'^## (.+)',result)
                the_pin = re.findall(r'Cookie\d+=[\"|\']pt_key=.+;pt_pin=(.+);[\"|\']',configs[namenum+1])[0]
                with open(pushpath, 'r', encoding='utf-8') as f2:
                    pushtext = f2.read()
                checkpin = re.findall(f'(?:^|\n)pin\({the_pin}\)=[\"|\'](.*)[\"|\']',pushtext)
                if "## 请依次填入每个用户的Cookie" in result:
                    namelist[0] = ''
                name = "".join(namelist)
                if len(checkpin) == 0:
                    if len(namelist) == 0 or "## 请依次填入每个用户的Cookie" in result:
                        adds += f"账号：{i}\n"
                    else:
                        adds += f"{i}：{name}\n"
                else:
                    if len(namelist) == 0 or "## 请依次填入每个用户的Cookie" in result:
                        changes += f"账号：{i}\n"
                    else:
                        changes += f"{i}：{name}\n"
    except Exception as e:
        title = "错误"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")
    return adds, changes, cknums


@jdbot.on(events.NewMessage(chats=chat_id, from_users=chat_id, pattern=r'^推送$'))
async def wx_tuisong(event):
    try:
        adds, changes, cknums = await read_ckts()
        if len(cknums) == 0:
            await jdbot.send_message(chat_id, '您还没有添加Cookie哦，请先添加！')
        else:
            async with jdbot.conversation(int(chat_id), timeout=50) as conv:
                msg = await conv.send_message("pushplus一对一推送，请做出您的选择：")
                buttons = [
                    Button.inline("对未加推送新增", data="adds"),  # 读取token时，replace没用的都删掉
                    Button.inline("对已有推送修改", data="changes"),
                    Button.inline("删除无用token", data="delete"),
                    Button.inline('取消对话', data='cancel')
                ]
                msg = await jdbot.edit_message(msg, 'pushplus一对一推送，请做出您的选择：', buttons=split_list(buttons, row))
                convdata = await conv.wait_event(press_event(int(chat_id)))
                res = bytes.decode(convdata.data)
                if res == 'cancel':
                    await jdbot.edit_message(msg, '对话已取消')
                    conv.cancel()
                    return False
                elif res == 'changes':
                    if len(changes) == 0:
                        await jdbot.edit_message(msg, '所有账号均无推送token，请先新增！')
                        conv.cancel()
                        return False
                    else:
                        btns, btns_1 = [], []
                        a = changes.split('\n')
                        for change in a:
                            btn = Button.inline(f"{change}", data=change)
                            btns_1.append(btn)
                        btns = split_list(btns_1, row)
                        btns.append([Button.inline('取消对话', data='cancel')])
                        msg = await jdbot.edit_message(msg, '对指定账号修改推送token，请做出选择：', buttons=btns)
                        convdata = await conv.wait_event(press_event(int(chat_id)))
                        res1 = bytes.decode(convdata.data)
                        if res1 == 'cancel':
                            await jdbot.edit_message(msg, '对话已取消')
                            conv.cancel()
                            return False
                        else:
                            cknum = re.findall(f'(\d+).*', res1.replace('账号', '').replace('：', ''))[0]
                            ckname = re.findall(f'\d+(.*)', res1.replace('账号', '').replace('：', ''))[0]
                            with open(path, 'r', encoding='utf-8') as f3:
                                configs = f3.read()
                            ck_pin = re.findall(f'(?:^|\n)Cookie{cknum}=[\"|\']pt_key=.+;pt_pin=(.+);[\"|\']', configs)[0]
                            with open(pushpath, 'r', encoding='utf-8') as f4:
                                tokens = f4.read()
                            the_token = re.findall(f'(?:^|\n)pin\({ck_pin}\)=[\"|\'](.*)[\"|\']', tokens)[0]
                            await jdbot.delete_messages(chat_id, msg)
                            msg = await jdbot.send_message(chat_id, f'```{the_token}```')
                            msg_new = await jdbot.send_message(chat_id, f'您选择了：账号{cknum}（{ckname}）\n上一条消息是其旧推送token\n请回复您需要修改的新推送token：')
                            note = await conv.get_response()
                            note = f"{note.raw_text}"
                            if 'token' in note:
                                newtoken = re.findall(f'(?:.|\n)*token[:|：](\w+)', note)[0]
                            else:
                                newtoken = note.replace(' ', '').replace(':', '').replace('：', '').replace('\n', '')
                            tokens = re.sub(f'pin\({ck_pin}\)=[\"|\'].*[\"|\']', f'pin({ck_pin})="{newtoken}"', tokens)
                            with open(pushpath,'w',encoding='utf-8') as f5:
                                f5.write(tokens)
                            await jdbot.delete_messages(chat_id, msg)
                            await jdbot.delete_messages(chat_id, msg_new)
                            await jdbot.send_message(chat_id, f'账号{cknum}（{ckname}）成功修改推送token：\n```{newtoken}```')
                            conv.cancel()
                elif res == 'adds':
                    if len(adds) == 0:
                        await jdbot.edit_message(msg, '所有账号均有推送token，无需新增！')
                        conv.cancel()
                        return False
                    else:
                        btns1, btns_2 = [], []
                        b = adds.split('\n')
                        for add in b:
                            btn1 = Button.inline(f"{add}", data=add)
                            btns_2.append(btn1)
                        btns1 = split_list(btns_2, row)
                        btns1.append([Button.inline('取消对话', data='cancel')])
                        msg = await jdbot.edit_message(msg, '对指定账号新增推送token，请做出选择：', buttons=btns1)
                        convdata = await conv.wait_event(press_event(int(chat_id)))
                        res2 = bytes.decode(convdata.data)
                        if res2 == 'cancel':
                            await jdbot.edit_message(msg, '对话已取消')
                            conv.cancel()
                            return False
                        else:
                            cknum1 = re.findall(f'(\d+).*', res2.replace('账号', '').replace('：', ''))[0]
                            ckname1 = re.findall(f'\d+(.*)', res2.replace('账号', '').replace('：', ''))[0]
                            with open(path, 'r', encoding='utf-8') as f6:
                                configs = f6.read()
                            ck_pin = re.findall(f'(?:^|\n)Cookie{cknum1}=[\"|\']pt_key=.+;pt_pin=(.+);[\"|\']', configs)[0]
                            await jdbot.delete_messages(chat_id, msg)
                            newmsg = await jdbot.send_message(chat_id, f'您选择了：账号{cknum1}（{ckname1}）\n请回复您需要新增的推送token：')
                            note1 = await conv.get_response()
                            note1 = f"{note1.raw_text}"
                            if 'token' in note1:
                                newtoken = re.findall(f'(?:.|\n)*token[:|：](\w+)', note1)[0]
                            else:
                                newtoken = note1.replace(' ', '').replace(':', '').replace('：', '').replace('\n', '')
                            with open(pushpath, 'r', encoding='utf-8') as f7:
                                thepush = f7.readlines()
                            for push in thepush:
                                if push.find(f'## 示例：pin') != -1:
                                    pushline = thepush.index(push) + 2
                            thepush.insert(pushline, f'pin({ck_pin})="{newtoken}"\n')
                            new_push = ''.join(thepush)
                            with open(pushpath,'w',encoding='utf-8') as f8:
                                f8.write(new_push)
                            await jdbot.delete_messages(chat_id, newmsg)
                            await jdbot.send_message(chat_id, f'账号{cknum1}（{ckname1}）成功新增推送token：\n```{newtoken}```')
                            conv.cancel()
                elif res == 'delete':
                    while True:
                        with open(pushpath, 'r', encoding='utf-8') as f1:
                            pushs = f1.read()
                        Allpush = re.findall(r'(?:^|\n)pin\((.+)\)=[\"|\'].*[\"|\']', pushs)
                        pins = []
                        for pin in Allpush:
                            with open(path, 'r', encoding='utf-8') as f:
                                cookies = f.read()
                            check_ck = re.findall(f'(?:^|\n)Cookie\d+=[\"|\']pt_key=.+;pt_pin={pin};[\"|\']', cookies)
                            if len(check_ck) == 0:
                                pins.append(pin)
                        if len(Allpush) == 0:
                            await jdbot.edit_message(msg, '所有账号均无推送token，无需删除！')
                            conv.cancel()
                            return False
                        elif len(pins) == 0:
                            await jdbot.edit_message(msg, '所有推送token都正常工作，无需删除！')
                            conv.cancel()
                            return False
                        else:
                            btns3 = []
                            num = 0
                            the_pin = ""
                            for the_pin in pins:
                                num += 1
                                btn = Button.inline(f"推送token({num})", data=the_pin)
                                btns3.append(btn)
                            btns3.append(Button.inline('取消对话', data='cancel'))
                            msg = await jdbot.edit_message(msg, f'以下是cookie已不存在的推送token\n若要删除，请做出你的选择：', buttons=split_list(btns3, row))
                            convdata = await conv.wait_event(press_event(int(chat_id)))
                            res3 = bytes.decode(convdata.data)
                            if res3 == 'cancel':
                                await jdbot.edit_message(msg, '对话已取消')
                                conv.cancel()
                                return False
                            else:      
                                await jdbot.delete_messages(chat_id, msg)
                                pinmsg = await jdbot.send_message(chat_id, f"```{the_pin}```")
                                btns4 = [
                                    Button.inline("删除token", data="deletoken"),
                                    Button.inline("返回上级", data="upmenu"),
                                    Button.inline("取消对话", data="cancel")
                                ]
                                msg = await conv.send_message(f'上一条为您选择的推送token对应的pt_pin\n该pt_pin对应的cookie已不存在\n请做出您的选择：', buttons=split_list(btns4, row))
                                convdata = await conv.wait_event(press_event(int(chat_id)))
                                res4 = bytes.decode(convdata.data)
                                if res4 == 'cancel':
                                    await jdbot.delete_messages(chat_id, pinmsg)
                                    await jdbot.edit_message(msg, '对话已取消')
                                    conv.cancel()
                                    return False
                                elif res4 == 'upmenu':
                                    await jdbot.delete_messages(chat_id, pinmsg)
                                elif res4 == 'deletoken':
                                    await jdbot.delete_messages(chat_id, pinmsg)
                                    await jdbot.delete_messages(chat_id, msg)                                    
                                    with open(pushpath, 'r', encoding='utf-8') as f2:
                                        pushlist = f2.readlines()
                                    for result in pushlist:
                                        token = re.findall(f'pin\({res3}\)=[\"|\'](.*)[\"|\']', result)
                                        if len(token) != 0:
                                            tokenline = pushlist.index(result)
                                            break
                                    del pushlist[tokenline]
                                    with open(pushpath, 'w', encoding='utf-8') as f3:
                                        f3.write("".join(pushlist))
                                    await asyncio.sleep(0.3)
                                    await jdbot.send_message(chat_id, f'成功为删除推送token：\n```{token[0]}```')
                                    conv.cancel()
                                    return False
    except exceptions.TimeoutError:
        await jdbot.edit_message(msg, '选择已超时，对话已停止，感谢你的使用')
    except Exception as e:
        title = "★错误★"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")
