#!/usr/bin/env python3
# Author : Annyooo
# Data   : 2021-08-27
# 从F12抓的整个字符串读取cookie，不管是不是多行或有空格，不管pt_key和pt_pin在不在一起，均可。

from .. import jdbot, chat_id, logger
from telethon import events, Button
from .utils import press_event
from asyncio import exceptions
from ..bot.utils import row, split_list
import re, os, sys

configfile = f"/jd/config/config.sh"

@jdbot.on(events.NewMessage(chats=chat_id, from_users=chat_id, pattern=r'(?:\n|.)*pt_key=(.*?);.*'))
async def readcookie(event):
    try:
        msg = await jdbot.send_message(chat_id, f'获取到京东Cookie，开始读取 . . .')
        message = event.message.text.replace(' ', '')
        pt_keylist = re.findall('(?:\n|.)*pt_key=(.*?);.*', message)
        pt_pinlist = re.findall('(?:\n|.)*pt_pin=(.*?);.*', message)
        if len(pt_keylist) != 0 and len(pt_pinlist) != 0:
            pt_key = pt_keylist[0]
            pt_pin = pt_pinlist[0]
            cookie = f"pt_key={pt_key};pt_pin={pt_pin};"
            with open(configfile, 'r', encoding='utf-8') as f1:
                result = f1.read()
            if len(re.findall(f'(?:^|\n)Cookie\d+=[\"|\']pt_key=.*;pt_pin={pt_pin};[\"|\']', result)) != 0:
                num = re.findall(f'(?:^|\n)Cookie(\d+)=[\"|\']pt_key=.*;pt_pin={pt_pin};[\"|\']', result)[0]
                if pt_key not in result:
                    result = re.sub(f'Cookie{num}=[\"|\']pt_key=.*;pt_pin={pt_pin};[\"|\']', f'Cookie{num}=\"{cookie}\"', result)
                    with open(configfile, 'w', encoding='utf-8') as f2:
                        f2.write(result)
                    await jdbot.edit_message(msg, f'账号{num}：Cookie替换成功\n```{cookie}```')
                    block = ''
                    with open(configfile, 'r', encoding='utf-8') as f3:
                        configs = f3.readlines()
                    for config in configs:
                        if "TempBlockCookie" in config and "##" not in config and "举例" not in config:
                            line = configs.index(config)
                            blocks = re.findall(r'"([^"]*)"', config)[0]
                            if len(blocks) == 0:
                                blocks = []
                            elif " " in blocks:
                                blocks = list(map(int, blocks.split(" ")))
                            else:
                                blocks = [int(blocks)]
                            if int(num) in blocks:
                                block = True
                            break
                    if block:
                        blocks.remove(int(num))
                        blocks = " ".join('%s' % _ for _ in sorted(blocks, reverse=False))
                        configs[line] = f'TempBlockCookie="{blocks}"\n'
                        with open(configfile, 'w', encoding='utf-8') as f4:
                            f4.write(''.join(configs))
                        await jdbot.send_message(chat_id, f"账号{num}：Cookie启用成功")
                    else:
                        await jdbot.send_message(chat_id, f"账号{num}：Cookie没有被屏蔽，正常使用")
                else:
                    await jdbot.edit_message(msg, f'账号{num}：Cookie无变化，无需更新\n```{cookie}```')
                try:
                    with open(configfile, 'r', encoding='utf-8') as f0:
                        configs = f0.readlines()
                    for config in configs:
                        if config.find(f'Cookie{num}="pt_key=') != -1:
                            line_num = configs.index(config)
                    nameline = configs[line_num-1]
                    result = re.findall(r'^## (.+)\n',nameline)
                    async with jdbot.conversation(int(chat_id), timeout=45) as conv:
                        if len(result) == 0 or "## 请依次填入每个用户的Cookie" in nameline:
                            msg = await conv.send_message("该Cookie还没有备注名字哦！\n是否需要备注？")
                            names = [
                                Button.inline("添加备注", data="name"),
                                Button.inline('取消会话', data='cancel')
                            ]
                            msg = await jdbot.edit_message(msg, '该Cookie还没有备注名字哦！\n是否需要备注？', buttons=split_list(names, row))
                            convdata = await conv.wait_event(press_event(int(chat_id)))
                            res = bytes.decode(convdata.data)
                            if res == 'cancel':
                                await jdbot.edit_message(msg, '对话已取消')
                                conv.cancel()
                                return False
                            elif res == 'name':
                                await jdbot.edit_message(msg, '请回复你需要备注的名字：')
                                note = await conv.get_response()
                                note = f"{note.raw_text}"
                                configs.insert(line_num, f'## {note}\n')
                                with open(configfile, 'w', encoding='utf-8') as f1:
                                    f1.write(''.join(configs))
                                await jdbot.delete_messages(chat_id, msg)
                                await jdbot.send_message(chat_id, f'账号{num}：成功添加备注（{note}）')
                                conv.cancel()
                        elif len(result) != 0 and "## 请依次填入每个用户的Cookie" not in nameline:
                            msg = await conv.send_message(f"该Cookie备注名为：{result[0]}\n是否需要修改？")
                            change_names = [
                                Button.inline("修改备注", data="change_name"),
                                Button.inline('取消会话', data='cancel')
                            ]
                            msg = await jdbot.edit_message(msg, f"该Cookie备注名为：{result[0]}\n是否需要修改？", buttons=split_list(change_names, row))
                            convdata = await conv.wait_event(press_event(int(chat_id)))
                            res2 = bytes.decode(convdata.data)
                            if res2 == 'cancel':
                                await jdbot.edit_message(msg, '对话已取消')
                                conv.cancel()
                                return False
                            elif res2 == 'change_name':
                                await jdbot.edit_message(msg, '请回复你需要修改的新备注：')
                                note2 = await conv.get_response()
                                note2 = f"{note2.raw_text}"
                                configs[line_num-1] = f'## {note2}\n' # 指定列表位置的元素 赋予新值，相当于替换。若用read()读取整个文本，再re.sub替换，其他相同匹配结果也会被替换。
                                with open(configfile,'w',encoding='utf-8') as f1:
                                    f1.write(''.join(configs))
                                await jdbot.delete_messages(chat_id, msg)
                                await jdbot.send_message(chat_id, f'账号{num}：成功修改备注（{note2}）')
                                conv.cancel()
                except exceptions.TimeoutError:
                    await jdbot.edit_message(msg, '选择已超时，对话已停止，感谢你的使用')
            else:
                with open(configfile, 'r', encoding='utf-8') as f2:
                    empcks = f2.read()
                delcks = re.sub('(?:^|\n?)Cookie\d+=[\"|\'][\"|\']\n?','\n',empcks) # 删除所有空ck行
                with open(configfile,'w',encoding='utf-8') as f3:
                    f3.write(delcks)
                ckreg = re.compile(r'pt_key=\S*?;pt_pin=\S*?;')
                with open(configfile, 'r', encoding='utf-8') as f4:
                    cookiestext = f4.read()
                cookies = ckreg.findall(cookiestext)
                for ck in cookies:
                    if ck == 'pt_key=xxxxxxxxxx;pt_pin=xxxx;':
                        cookies.remove(ck)
                        break
                ck_num =len(cookies)
                new_ck_num =len(cookies) + 1
                with open(configfile, 'r', encoding='utf-8') as f5:
                    configs = f5.readlines()
                for config in configs:
                    if ck_num >= 1 and config.find(f'Cookie{ck_num}=') != -1:
                        newck_line = configs.index(config) + 1
                        configs.insert(newck_line, f'Cookie{new_ck_num}="{cookie}"\n')
                        with open(configfile, 'w', encoding='utf-8') as f6:
                            f6.write(''.join(configs))
                    elif ck_num == 0 and config.find(f'没有其他字段）：pt_key=xxxxxxxxxx;pt_pin=xxxx;') != -1:
                        newck_line = configs.index(config) + 1
                        configs.insert(newck_line, f'Cookie{new_ck_num}="{cookie}"\n')
                        with open(configfile, 'w', encoding='utf-8') as f7:
                            f7.write(''.join(configs))
                        break
                await jdbot.edit_message(msg, f'新Cookie，已成功新增为账号{new_ck_num}\n```{cookie}```')
                try:
                    with open(configfile, 'r', encoding='utf-8') as f0:
                        configs = f0.readlines()
                    for config in configs:
                        if config.find(f'Cookie{new_ck_num}="pt_key=') != -1:
                            line_num0 = configs.index(config)
                    nameline0 = configs[line_num0-1]
                    result0 = re.findall(r'^## (.+)\n',nameline0)
                    async with jdbot.conversation(int(chat_id), timeout=45) as conv:
                        if len(result0) == 0 or "## 请依次填入每个用户的Cookie" in nameline0:
                            msg = await conv.send_message("新Cookie还没有备注名字哦！\n是否需要备注？")
                            new_names = [
                                Button.inline("添加备注", data="newname"),
                                Button.inline('取消会话', data='cancel')
                            ]
                            msg = await jdbot.edit_message(msg, '新Cookie还没有备注名字哦！\n是否需要备注？', buttons=split_list(new_names, row))
                            convdata = await conv.wait_event(press_event(int(chat_id)))
                            res = bytes.decode(convdata.data)
                            if res == 'cancel':
                                await jdbot.edit_message(msg, '对话已取消')
                                conv.cancel()
                                return False
                            elif res == 'newname':
                                await jdbot.edit_message(msg, '请回复你需要备注的名字：')
                                note3 = await conv.get_response()
                                note3 = f"{note3.raw_text}"
                                configs.insert(line_num0, f'## {note3}\n') # 插入指定位置
                                with open(configfile, 'w', encoding='utf-8') as f1:
                                    f1.write(''.join(configs))
                                await jdbot.delete_messages(chat_id, msg)
                                await jdbot.send_message(chat_id, f'账号{new_ck_num}：成功添加备注（{note3}）')
                                conv.cancel()
                except exceptions.TimeoutError:
                    await jdbot.edit_message(msg, '选择已超时，对话已停止，感谢你的使用')
        else:
            await jdbot.edit_message(msg, f'抱歉，没有读取到Cookie，请检查！')
    except Exception as e:
        title = "错误"
        name = "文件名：" + os.path.split(__file__)[-1].split(".")[0]
        function = "函数名：" + sys._getframe().f_code.co_name
        tip = '建议百度/谷歌进行查询'
        await jdbot.send_message(chat_id, f"{title}\n\n{name}\n{function}\n错误原因：{str(e)}\n\n{tip}")
        logger.error(f"错误--->{str(e)}")
